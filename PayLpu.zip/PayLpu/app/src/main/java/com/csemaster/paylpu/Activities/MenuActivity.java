package com.csemaster.paylpu.Activities;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.csemaster.paylpu.Adapters.CartValueAdapter;
import com.csemaster.paylpu.Adapters.MenuAdapter;
import com.csemaster.paylpu.Modals.CartModel;
import com.csemaster.paylpu.R;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Set;

public class MenuActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    ArrayList<String> foodItemNames=new ArrayList<>();
    ArrayList<String> foodItemImages=new ArrayList<>();
    ArrayList<String> foodItemPrices=new ArrayList<>();
    public static TextView totalItems,totalPrice,shopName;
    public static CardView cartmini;
    String name;
    int quantity;
    String price;
    String shop;
    String uId;

    String foodname,foodImage,foodPrice;
    FirebaseFirestore firebaseFirestore=FirebaseFirestore.getInstance();
    CollectionReference collectionReference=firebaseFirestore.collection("ShopMenus");
    CollectionReference cartCollectionReference=firebaseFirestore.collection("Cart");
    BottomSheetBehavior sheetBehavior;
    LinearLayout bottom_sheet;
    Button btn_bottom_sheet;
    ArrayList<CartModel> cartModelArrayList=new ArrayList<>();
    RecyclerView cartValueRecyclerView;
    public static CartValueAdapter cartValueAdapter;
    int totalItemInCart,totalPriceInCart=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        recyclerView=findViewById(R.id.menuRecyclerView);
        bottom_sheet=findViewById(R.id.bottom_sheet);
        sheetBehavior=BottomSheetBehavior.from(bottom_sheet);
        cartValueRecyclerView=findViewById(R.id.cartValueRecyclerView);
        cartmini=findViewById(R.id.cartMini);
        shopName=findViewById(R.id.shopNameInCart);
        shopName.setText(getIntent().getStringExtra("ShopName"));
        totalItems=findViewById(R.id.totalItemsInCart);


        btn_bottom_sheet=findViewById(R.id.btn_bottom_sheet);
        cartmini.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cartCollectionReference
                        .whereEqualTo("uId",FirebaseAuth.getInstance().getCurrentUser().getUid())
                        .whereEqualTo("shopName",getIntent().getStringExtra("ShopName"))
                        .addSnapshotListener(new EventListener<QuerySnapshot>() {
                            @Override
                            public void onEvent(@Nullable QuerySnapshot queryDocumentSnapshots, @Nullable FirebaseFirestoreException e) {
                                if(queryDocumentSnapshots!=null && !queryDocumentSnapshots.isEmpty())
                                {
                                    cartModelArrayList.clear();
                                    for (QueryDocumentSnapshot queryDocumentSnapshot:queryDocumentSnapshots)
                                    {
                                        name=queryDocumentSnapshot.getString("itemName");
                                        quantity=  queryDocumentSnapshot.getLong("itemQuantity").intValue();
                                        price=queryDocumentSnapshot.getString("itemPrice");
                                        shop=queryDocumentSnapshot.getString("shopName");
                                        uId=queryDocumentSnapshot.getString("uId");
                                        //totalItemInCart=totalItemInCart+quantity;
                                        cartModelArrayList.add(new CartModel(name, quantity,price,shop,uId));

                                    }

                                    //totalItems.setText(String.valueOf(totalItemInCart));

                                    cartValueRecyclerView.setLayoutManager(new LinearLayoutManager(MenuActivity.this));
                                    cartValueRecyclerView.setHasFixedSize(true);

                                    cartValueAdapter=new CartValueAdapter(MenuActivity.this,cartModelArrayList);
                                    cartValueRecyclerView.setAdapter(cartValueAdapter);
                                    cartValueAdapter.notifyDataSetChanged();
                                }
                            }
                        });
                if (sheetBehavior.getState() != BottomSheetBehavior.STATE_EXPANDED) {
                    sheetBehavior.setState(BottomSheetBehavior.STATE_EXPANDED);
                    btn_bottom_sheet.setText("Close sheet");

                } else {
                    sheetBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);
                    btn_bottom_sheet.setText("Expand sheet");
                }
            }
        });

        sheetBehavior.setBottomSheetCallback(new BottomSheetBehavior.BottomSheetCallback() {
            @Override
            public void onStateChanged(@NonNull View view, int newState) {
                switch (newState) {
                    case BottomSheetBehavior.STATE_HIDDEN:
                        break;
                    case BottomSheetBehavior.STATE_EXPANDED: {
                        btn_bottom_sheet.setText("Close Sheet");
                    }
                    break;
                    case BottomSheetBehavior.STATE_COLLAPSED: {
                        btn_bottom_sheet.setText("Expand Sheet");
                    }
                    break;
                    case BottomSheetBehavior.STATE_DRAGGING:
                        break;
                    case BottomSheetBehavior.STATE_SETTLING:
                        break;
                }
            }

            @Override
            public void onSlide(@NonNull View view, float v) {

            }
        });

        collectionReference
                .whereEqualTo("vendorName",getIntent().getStringExtra("ShopName"))
                .addSnapshotListener(new EventListener<QuerySnapshot>() {
                    @Override
                    public void onEvent(@Nullable QuerySnapshot queryDocumentSnapshots, @Nullable FirebaseFirestoreException e) {
                        if(queryDocumentSnapshots!=null && !queryDocumentSnapshots.isEmpty())
                        {
                            for (QueryDocumentSnapshot snapshot:queryDocumentSnapshots)
                            {
                                foodname=snapshot.getString("itemName");
                                foodImage=snapshot.getString("itemUrl");
                                foodPrice=snapshot.getString("itemPrice");
//                              Toast.makeText(MenuActivity.this, "ItemInfo"+foodname, Toast.LENGTH_SHORT).show();

                                foodItemNames.add(foodname);
                                foodItemImages.add(foodImage);
                                foodItemPrices.add(foodPrice);
                            }

                            recyclerView.setLayoutManager(new LinearLayoutManager(MenuActivity.this));
                            recyclerView.setHasFixedSize(true);

                            MenuAdapter menuAdapter=new MenuAdapter(foodItemNames,foodItemPrices,foodItemImages,MenuActivity.this,getIntent().getStringExtra("ShopName"));
                            recyclerView.setAdapter(menuAdapter);
                            menuAdapter.notifyDataSetChanged();
                        }
                        else
                        {
                            Toast.makeText(MenuActivity.this, "No Menu Found"+queryDocumentSnapshots.isEmpty(), Toast.LENGTH_SHORT).show();
                        }
                    }
                });



    }


}

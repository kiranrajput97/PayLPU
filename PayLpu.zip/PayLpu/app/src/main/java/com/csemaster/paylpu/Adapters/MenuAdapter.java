package com.csemaster.paylpu.Adapters;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.csemaster.paylpu.Activities.MainActivity;
import com.csemaster.paylpu.Activities.MenuActivity;
import com.csemaster.paylpu.Modals.CartModel;
import com.csemaster.paylpu.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class MenuAdapter extends RecyclerView.Adapter<MenuAdapter.MenuViewHolder> {
    ArrayList<String> foodItemNames=new ArrayList<>();
    ArrayList<String> foodItemPrices=new ArrayList<>();
    ArrayList<String> foodItemImages=new ArrayList<>();
    int quantity;
    String shopName;

    FirebaseAuth firebaseAuth;
    FirebaseFirestore firebaseFirestore=FirebaseFirestore.getInstance();
    CollectionReference collectionReference=firebaseFirestore.collection("Cart");
    String documnentId;

    Context context;

    public MenuAdapter(ArrayList<String> foodItemNames, ArrayList<String> foodItemPrices, ArrayList<String> foodItemImages, Context context,String shopName) {
        this.foodItemNames = foodItemNames;
        this.foodItemPrices = foodItemPrices;
        this.foodItemImages = foodItemImages;
        this.context = context;
        this.shopName=shopName;
        firebaseAuth=FirebaseAuth.getInstance();
    }

    @NonNull
    @Override
    public MenuAdapter.MenuViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v= LayoutInflater.from(parent.getContext()).inflate(R.layout.menusinglelayout,parent,false);
        return new MenuViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull final MenuAdapter.MenuViewHolder holder, final int position) {


        holder.foodName.setText(foodItemNames.get(position));
        holder.foodPrice.setText(foodItemPrices.get(position));
        Glide.with(context).load(foodItemImages.get(position)).into(holder.foodImage);

        collectionReference
                .whereEqualTo("itemName",foodItemNames.get(position))
                .addSnapshotListener(new EventListener<QuerySnapshot>() {
                    @Override
                    public void onEvent(@Nullable QuerySnapshot queryDocumentSnapshots, @Nullable FirebaseFirestoreException e) {
                        if(!queryDocumentSnapshots.isEmpty() && queryDocumentSnapshots!=null)
                        {
                            holder.addToCartButton.setText("✔ Added to Cart");
                            holder.addToCartButton.setTextColor(Color.GREEN);
                            holder.addToCartButton.setClickable(false);
                        }
                    }
                });


        holder.addToCartButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                holder.addToCartButton.setText("✔ Added to Cart");
                holder.addToCartButton.setTextColor(Color.GREEN);
                holder.addToCartButton.setClickable(false);
                addToCart(shopName,foodItemNames.get(position),foodItemPrices.get(position),quantity);
                MenuActivity.cartValueAdapter.notifyDataSetChanged();
            }
        });

    }

    @Override
    public int getItemCount() {
        return foodItemNames.size();
    }

    public class MenuViewHolder extends RecyclerView.ViewHolder {
        TextView foodName,foodPrice,totalItem;
        ImageView foodImage;
        Button addToCartButton;
        FloatingActionButton plus,minus;
        LinearLayout cartValue;

        public MenuViewHolder(@NonNull View itemView) {
            super(itemView);
            foodName=itemView.findViewById(R.id.foodItemName);
            foodPrice=itemView.findViewById(R.id.foodPrice);
            foodImage=itemView.findViewById(R.id.foodImage);
            addToCartButton=itemView.findViewById(R.id.addtoCartButton);
        }
    }

    void addToCart(String shopName,String itemName,String itemPrice,int itemQuantity)
    {
        Map<String,Object> cart=new HashMap<>();
        cart.put("shopName",shopName);
        cart.put("itemName",itemName);
        cart.put("itemPrice",itemPrice);
        cart.put("itemQuantity",1);
        cart.put("uId",firebaseAuth.getCurrentUser().getUid());

        collectionReference.add(cart)
                .addOnCompleteListener(new OnCompleteListener<DocumentReference>() {
                    @Override
                    public void onComplete(@NonNull Task<DocumentReference> task) {
                        if(task.isSuccessful())
                        {
                            Toast.makeText(context, "Data Successfully Added", Toast.LENGTH_SHORT).show();
                        }
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(context, "Exception Occured:"+e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }


    void updateQuantity(final int itemQuantity, final String itemName, final String itemPrice, final String shopName)
    {
        collectionReference
                .whereEqualTo("itemName",itemName)
                .addSnapshotListener(new EventListener<QuerySnapshot>() {
                    @Override
                    public void onEvent(@Nullable QuerySnapshot queryDocumentSnapshots, @Nullable FirebaseFirestoreException e) {
                        for(QueryDocumentSnapshot queryDocumentSnapshot:queryDocumentSnapshots)
                        {
                            documnentId=queryDocumentSnapshot.getId();
                            DocumentReference documentReference=collectionReference.document(documnentId);

                            Map<String,Object> cart=new HashMap<>();
                            cart.put("shopName",shopName);
                            cart.put("itemName",itemName);
                            cart.put("itemPrice",itemPrice);
                            cart.put("itemQuantity",itemQuantity);
                            cart.put("uId",firebaseAuth.getCurrentUser().getUid());


                            documentReference
                                    .set(cart)
                                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                         if (task.isSuccessful())
                                         {
                                             Toast.makeText(context, "Data Successfully Updated", Toast.LENGTH_SHORT).show();
                                         }
                                        }
                                    })
                            .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Toast.makeText(context, "Data Updation Failed"+e.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        });
                        }
                    }
                });
    }
}

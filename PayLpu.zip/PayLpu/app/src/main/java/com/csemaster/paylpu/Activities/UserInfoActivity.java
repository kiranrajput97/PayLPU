package com.csemaster.paylpu.Activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.csemaster.paylpu.Modals.UserModel;
import com.csemaster.paylpu.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.Timestamp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.common.BitMatrix;
import com.journeyapps.barcodescanner.BarcodeEncoder;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

public class UserInfoActivity extends AppCompatActivity {
    EditText userName;
    ImageView profileImage;
    Button saveButton;
    Uri qrUri;
    Bitmap bm;
    ProgressBar userInfoProcess;
    Uri uriProfileImage;
    FirebaseAuth firebaseAuth;
    StorageReference storageReference;
    FirebaseFirestore firebaseFirestore=FirebaseFirestore.getInstance();
    CollectionReference collectionReference=firebaseFirestore.collection("UserInfo");
    String mobileNo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_info);
        userName=findViewById(R.id.userName);
        profileImage=findViewById(R.id.imageViewProfile);
        saveButton=findViewById(R.id.buttonSave);
        userInfoProcess=findViewById(R.id.userInfoProgress);

        Intent intent=getIntent();
        mobileNo=intent.getStringExtra("Mobile");
        profileImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showImageChooser();
            }
        });
        firebaseAuth=FirebaseAuth.getInstance();
        storageReference=FirebaseStorage.getInstance().getReference();
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                saveUserInformation();
            }
        });
    }

    private void saveUserInformation() {
        userInfoProcess.setVisibility(View.VISIBLE);
        final String displayName=userName.getText().toString().trim();

        try{
            MultiFormatWriter multiFormatWriter=new MultiFormatWriter();
            BitMatrix bitMatrix=multiFormatWriter.encode(mobileNo, BarcodeFormat.QR_CODE,500,500);
            BarcodeEncoder barcodeEncoder=new BarcodeEncoder();
            Bitmap bitmap=barcodeEncoder.createBitmap(bitMatrix);
            qrUri=getImageUri(this,bitmap);
            Toast.makeText(this, "QRURI:"+qrUri, Toast.LENGTH_SHORT).show();
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

        if(displayName.isEmpty())
        {
            userName.setError("Name Required");
            userName.requestFocus();
            return;
        }

        final FirebaseUser user=firebaseAuth.getCurrentUser();

        if(user!=null && uriProfileImage!=null && qrUri!=null)
        {
            final StorageReference filePath=storageReference.child("ProfileImages")
                    .child("profile_image"+ Timestamp.now().getSeconds());
            final StorageReference qrPath=storageReference.child("QRCodeImages")
                    .child("qrcode_image"+ Timestamp.now().getSeconds());

            filePath.putFile(uriProfileImage)
                    .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                            filePath.getDownloadUrl()
                            .addOnSuccessListener(new OnSuccessListener<Uri>() {
                                @Override
                                public void onSuccess(Uri uri) {
                                    final UserModel userModel=new UserModel();
                                    userModel.setName(displayName);
                                    userModel.setuId(firebaseAuth.getCurrentUser().getUid());
                                    userModel.setProfileImageUrl(uri.toString());

                                    qrPath.putFile(qrUri)
                                            .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                                                @Override
                                                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                                                  qrPath.getDownloadUrl()
                                                  .addOnSuccessListener(new OnSuccessListener<Uri>() {
                                                      @Override
                                                      public void onSuccess(Uri uri) {
                                                          userModel.setQrCodeImageUrl(uri.toString());
                                                          collectionReference.add(userModel)
                                                                  .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                                                                      @Override
                                                                      public void onSuccess(DocumentReference documentReference) {
                                                                          userInfoProcess.setVisibility(View.GONE);
                                                                          startActivity(new Intent(UserInfoActivity.this,Dashboard.class));
                                                                      }
                                                                  })
                                                                  .addOnFailureListener(new OnFailureListener() {
                                                                      @Override
                                                                      public void onFailure(@NonNull Exception e) {
                                                                          userInfoProcess.setVisibility(View.GONE);
                                                                          Toast.makeText(UserInfoActivity.this, "Unable to Store your Information", Toast.LENGTH_SHORT).show();
                                                                      }
                                                                  });
                                                      }
                                                  });
                                                }
                                            });


                                }
                            });
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            userInfoProcess.setVisibility(View.GONE);
                        }
                    });
        }
    }

    public Uri getImageUri(Context inContext, Bitmap inImage) {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        inImage.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
        String path = MediaStore.Images.Media.insertImage(inContext.getContentResolver(), inImage, "Title", null);
        return Uri.parse(path);
    }

    private void showImageChooser()
    {
        Intent intent=new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent,"Select Profile Image"),131);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==131 && resultCode==RESULT_OK && data!=null && data.getData()!=null)
        {
           uriProfileImage=data.getData();
            try {
                bm= MediaStore.Images.Media.getBitmap(getContentResolver(),uriProfileImage);
                profileImage.setImageBitmap(bm);

            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

//    private void uploadImageToFirebaseStorage() {
//        StorageReference storageReference= FirebaseStorage.getInstance().getReference("profilePics/"+System.currentTimeMillis()+".jpg");
//        if(uriProfileImage!=null)
//        {
//            storageReference.putFile(uriProfileImage).addOnSuccessListener(UserInfoActivity.this, new OnSuccessListener<UploadTask.TaskSnapshot>() {
//                @Override
//                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
//                    Toast.makeText(UserInfoActivity.this, "Message:"+ taskSnapshot.getMetadata(),Toast.LENGTH_SHORT).show();
//                }
//            });
//        }
//    }
}

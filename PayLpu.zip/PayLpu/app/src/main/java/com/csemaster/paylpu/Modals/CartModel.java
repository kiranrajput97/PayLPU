package com.csemaster.paylpu.Modals;

public class CartModel {
    String name;
    int quantity;
    String price;
    String shopName;
    String uId;


    //Empty constuctor for firebase
    public CartModel() {

    }

    public CartModel(String name, int quantity, String price, String shopName, String uId) {
        this.name = name;
        this.quantity = quantity;
        this.price = price;
        this.shopName = shopName;
        this.uId = uId;
    }

    public String getShopName() {
        return shopName;
    }

    public void setShopName(String shopName) {
        this.shopName = shopName;
    }

    public String getuId() {
        return uId;
    }

    public void setuId(String uId) {
        this.uId = uId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }
}

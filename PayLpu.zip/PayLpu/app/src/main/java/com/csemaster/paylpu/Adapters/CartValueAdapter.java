package com.csemaster.paylpu.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.csemaster.paylpu.Modals.CartModel;
import com.csemaster.paylpu.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

public class CartValueAdapter  extends RecyclerView.Adapter<CartValueAdapter.CartValueViewHolder> {
    Context context;
    FirebaseFirestore firebaseFirestore=FirebaseFirestore.getInstance();
    CollectionReference collectionReference=firebaseFirestore.collection("Cart");
    FirebaseAuth firebaseAuth=FirebaseAuth.getInstance();
    Set<CartModel> cartModelSet;
    ArrayList<CartModel> cartModelArrayList;

    public CartValueAdapter(Context context, ArrayList<CartModel> cartModelArrayList) {
        this.context = context;
        //this.cartModelSet = cartModelSet;
        this.cartModelArrayList=cartModelArrayList;
        cartModelSet=new LinkedHashSet<>(cartModelArrayList);
        cartModelArrayList.clear();
        cartModelArrayList.addAll(cartModelSet);


    }

    @NonNull
    @Override
    public CartValueViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View vh= LayoutInflater.from(parent.getContext()).inflate(R.layout.singlecartvaluelayout,parent,false);
        return new CartValueViewHolder(vh);
    }

    @Override
    public void onBindViewHolder(@NonNull CartValueViewHolder holder, int position) {
        holder.itemName.setText(cartModelArrayList.get(position).getName());
        holder.quantity.setText(String.valueOf(cartModelArrayList.get(position).getQuantity()));
    }

    @Override
    public int getItemCount() {
        return cartModelArrayList.size();
    }

    public class CartValueViewHolder extends RecyclerView.ViewHolder {
        TextView itemName,quantity;
        FloatingActionButton plus,minus;

        public CartValueViewHolder(@NonNull View itemView) {
            super(itemView);
            itemName=itemView.findViewById(R.id.itemNameCartValue);
            quantity=itemView.findViewById(R.id.totalItem);
            plus=itemView.findViewById(R.id.plusFab);
            minus=itemView.findViewById(R.id.minusFab);
        }
    }
}


Please use mention link to download the jar for below methods 

  Link: https://github.com/Paytm-Payments/Paytm_Web_Sample_Kit_Java

  1. Generate Checksum:  
    public String genrateCheckSum(String merchantKey, TreeMap<String, String> paytmParams)
  2. Verify Checksum:  
    public boolean verifycheckSum(String merchantKey, TreeMap<String, String>  paytmParams,String paytmChecksum)
    
